
    {/* //Tomamos en una variable el id de la etiqueta id. */}
  var content = document.getElementById("contenido");
  {/* //Escribimos codigo html en el bloque del div siempre manejandolo con el id.
  // Puede cambiar el contenido para efectuar pruebas.
  //El codigo de estilo le da su vista buena al texto. */}
  content.innerHTML = "<p>Vamos a aprender JavaScript.</p>";
  
function sum(){
  var n1 = document.getElementById("n1").value;
  var n2 = document.getElementById("n2").value;
  var resultado = parseInt(n1)+parseInt(n2);
 alert(resultado);


 
}